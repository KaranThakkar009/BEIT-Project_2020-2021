// Descriptors profile
export const JSON_PROFILE = require('../descriptors/bnk48.json');
